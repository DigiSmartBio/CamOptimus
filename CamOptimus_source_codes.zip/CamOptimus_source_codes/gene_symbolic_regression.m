% gene_symbolic_regression.m is part of CamOptimus.
% 
% CamOptimus is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% CamOptimus is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with CamOptimus.  If not, see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file defines the commands and graphical user interface to set the
% parameters required to perform symbolic regression analysis.
    
function varargout = gene_symbolic_regression(varargin)
% GENE_SYMBOLIC_REGRESSION MATLAB code for gene_symbolic_regression.fig
%      GENE_SYMBOLIC_REGRESSION, by itself, creates a new GENE_SYMBOLIC_REGRESSION or raises the existing
%      singleton*.
%
%      H = GENE_SYMBOLIC_REGRESSION returns the handle to a new GENE_SYMBOLIC_REGRESSION or the handle to
%      the existing singleton*.
%
%      GENE_SYMBOLIC_REGRESSION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GENE_SYMBOLIC_REGRESSION.M with the given input arguments.
%
%      GENE_SYMBOLIC_REGRESSION('Property','Value',...) creates a new GENE_SYMBOLIC_REGRESSION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gene_symbolic_regression_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gene_symbolic_regression_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gene_symbolic_regression

% Last Modified by GUIDE v2.5 06-Jun-2016 15:32:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gene_symbolic_regression_OpeningFcn, ...
                   'gui_OutputFcn',  @gene_symbolic_regression_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gene_symbolic_regression is made visible.
function gene_symbolic_regression_OpeningFcn(hObject, eventdata, handles, varargin)
hObject.Name='CamOptimus: Symbolic Regression';
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gene_symbolic_regression (see VARARGIN)

% Choose default command line output for gene_symbolic_regression
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

set(handles.n_fac,'Enable','off');
set(handles.n_fac,'Value',1);
set(handles.obj_list1,'String','');
set(handles.obj_list2,'String','');
set(handles.fac_list1,'String','');
set(handles.fac_list2,'String','');
set(handles.add_obj,'Enable','off');
set(handles.rem_obj,'Enable','off');
set(handles.add_fac,'Enable','off');
set(handles.rem_fac,'Enable','off');
set(handles.plot_model,'Enable','off');
set(handles.model_type,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');
% UIWAIT makes gene_symbolic_regression wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gene_symbolic_regression_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in obj_list1.
function obj_list1_Callback(hObject, eventdata, handles)
% hObject    handle to obj_list1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns obj_list1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from obj_list1


% --- Executes during object creation, after setting all properties.
function obj_list1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to obj_list1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in fac_list1.
function fac_list1_Callback(hObject, eventdata, handles)
% hObject    handle to fac_list1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns fac_list1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from fac_list1


% --- Executes during object creation, after setting all properties.
function fac_list1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fac_list1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in load_par.
function load_par_Callback(hObject, eventdata, handles)
global var_list
global T
% hObject    handle to load_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file,path]=uigetfile('*.xls','Load Experiments');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    T=readtable(f,'ReadRowNames',true);
    var_list=T.Properties.VariableNames;
    n_var=num2str((1:size(var_list,2)-1)');
    set(handles.n_fac,'Enable','on');
    set(handles.n_fac,'String',n_var);
    set(handles.n_fac,'Value',1);
end
set(handles.obj_list1,'String','');
set(handles.obj_list2,'String','');
set(handles.fac_list1,'String','');
set(handles.fac_list2,'String','');
set(handles.add_obj,'Enable','off');
set(handles.rem_obj,'Enable','off');
set(handles.add_fac,'Enable','off');
set(handles.rem_fac,'Enable','off');
set(handles.plot_model,'Enable','off');
set(handles.model_type,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');

% --- Executes on selection change in obj_list2.
function obj_list2_Callback(hObject, eventdata, handles)
% hObject    handle to obj_list2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns obj_list2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from obj_list2


% --- Executes during object creation, after setting all properties.
function obj_list2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to obj_list2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in fac_list2.
function fac_list2_Callback(hObject, eventdata, handles)
% hObject    handle to fac_list2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns fac_list2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from fac_list2


% --- Executes during object creation, after setting all properties.
function fac_list2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fac_list2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in add_fac.
function add_fac_Callback(hObject, eventdata, handles)
A=get(handles.fac_list1,'Value');
B=get(handles.fac_list1,'String');
C=get(handles.fac_list2,'String');
D=sum(strcmp(B(A),C));
if D==0
    E=[C;B(A)];
    set(handles.fac_list2,'String',E);
end
F=get(handles.fac_list2,'String');
if isempty(F)
    set(handles.model_type,'Enable','off');
else
    set(handles.model_type,'Enable','on');
end
set(handles.plot_model,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');
% hObject    handle to add_fac (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rem_fac.
function rem_fac_Callback(hObject, eventdata, handles)
A=get(handles.fac_list2,'Value');
B=get(handles.fac_list2,'String');
if size(B,1)>1
    B(A)=[];
    if A==1
        A=1;
    else
        A=A-1;
    end
    set(handles.fac_list2,'Value',A);
    set(handles.fac_list2,'String',B);    
else
    set(handles.fac_list2,'String','');
    set(handles.model_type,'Enable','off');
end
set(handles.plot_model,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');

% hObject    handle to rem_fac (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in add_obj.
function add_obj_Callback(hObject, eventdata, handles)
A=get(handles.obj_list1,'Value');
B=get(handles.obj_list1,'String');
C=get(handles.obj_list2,'String');
D=sum(strcmp(B(A),C));
E=B(A);
set(handles.obj_list2,'String',E);
F=get(handles.fac_list2,'String');
if isempty(F)
    set(handles.model_type,'Enable','off');
else
    set(handles.model_type,'Enable','on');
end
set(handles.plot_model,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');

% hObject    handle to add_obj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rem_obj.
function rem_obj_Callback(hObject, eventdata, handles)
set(handles.obj_list2,'String','');
set(handles.model_type,'Enable','off');
set(handles.plot_model,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');

% hObject    handle to rem_obj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in adv_set.
function adv_set_Callback(hObject, eventdata, handles)
A=get(handles.adv_set,'Value');
if A==1
    set(handles.pop_size,'Enable','on');
    set(handles.pop_size,'String',500);
    set(handles.num_gen,'Enable','on');
    set(handles.num_gen,'String',500);
    set(handles.max_gene,'Enable','on');
    set(handles.max_gene,'String',4);
    set(handles.max_dep,'Enable','on');
    set(handles.max_dep,'String',3);
else
    set(handles.pop_size,'Enable','off');
    set(handles.pop_size,'String',500);
    set(handles.num_gen,'Enable','off');
    set(handles.num_gen,'String',500);
    set(handles.max_gene,'Enable','off');
    set(handles.max_gene,'String',4);
    set(handles.max_dep,'Enable','off');
    set(handles.max_dep,'String',3);
end
set(handles.plot_model,'Enable','on');
% hObject    handle to adv_set (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns adv_set contents as cell array
%        contents{get(hObject,'Value')} returns selected item from adv_set


% --- Executes during object creation, after setting all properties.
function adv_set_CreateFcn(hObject, eventdata, handles)
% hObject    handle to adv_set (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in model_type.
function model_type_Callback(hObject, eventdata, handles)
A=get(handles.model_type,'Value');
if A==2
    set(handles.val,'Enable','on');
    set(handles.val,'String',25);
    set(handles.ok_val,'Enable','on');
    set(handles.adv_set,'Enable','off');
else
    set(handles.val,'Enable','off');
    set(handles.ok_val,'Enable','off');
    set(handles.val,'String','');
    set(handles.adv_set,'Enable','on');
end
set(handles.plot_model,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');
% hObject    handle to model_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns model_type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from model_type


% --- Executes during object creation, after setting all properties.
function model_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to model_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function val_Callback(hObject, eventdata, handles)
% hObject    handle to val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of val as text
%        str2double(get(hObject,'String')) returns contents of val as a double


% --- Executes during object creation, after setting all properties.
function val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function max_gene_Callback(hObject, eventdata, handles)
% hObject    handle to max_gene (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of max_gene as text
%        str2double(get(hObject,'String')) returns contents of max_gene as a double


% --- Executes during object creation, after setting all properties.
function max_gene_CreateFcn(hObject, eventdata, handles)
% hObject    handle to max_gene (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function max_dep_Callback(hObject, eventdata, handles)
% hObject    handle to max_dep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of max_dep as text
%        str2double(get(hObject,'String')) returns contents of max_dep as a double


% --- Executes during object creation, after setting all properties.
function max_dep_CreateFcn(hObject, eventdata, handles)
% hObject    handle to max_dep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_gen_Callback(hObject, eventdata, handles)
% hObject    handle to num_gen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_gen as text
%        str2double(get(hObject,'String')) returns contents of num_gen as a double


% --- Executes during object creation, after setting all properties.
function num_gen_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_gen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in plot_model.
function plot_model_Callback(hObject, eventdata, handles)
global T
rng('shuffle')
A1=str2double(get(handles.pop_size,'String'));
B1=str2double(get(handles.num_gen,'String'));
C1=str2double(get(handles.max_gene,'String'));
D1=str2double(get(handles.max_dep,'String'));
H=get(handles.model_type,'Value');
if H==1
    E1=1;
else
    E1=str2double(get(handles.val,'String'));
end
F=sum(abs(round([A1 B1 C1 D1 E1])-[A1 B1 C1 D1 E1])<1e-10);

if F==5
%     fileID=fopen('my_config.m','wt');
%     fprintf(fileID,'function gp=my_config(gp)\n');
%     fprintf(fileID,'gp.runcontrol.pop_size=%d;\n',A1);
%     fprintf(fileID,'gp.runcontrol.num_gen=%d;\n',B1);
%     fprintf(fileID,'gp.genes.max_genes=%d;\n',C1);
%     fprintf(fileID,'gp.treedef.max_depth=%d;\n',D1);
%     fprintf(fileID,'load(''my_data.mat'')\n');
%     fprintf(fileID,'gp.userdata.xtrain=xtrain;\n');
%     fprintf(fileID,'gp.userdata.ytrain=ytrain;\n');
%     fprintf(fileID,'gp.userdata.xtest=xtest;\n');
%     fprintf(fileID,'gp.userdata.ytest=ytest;\n');
%     fprintf(fileID,'gp.nodes.inputs.num_inp=size(gp.userdata.xtrain,2);\n');
%     fprintf(fileID,'gp.nodes.functions.name={''times'',''minus'',''plus'',''rdivide''};');
%     fclose(fileID);
    A=get(handles.obj_list1,'String');
    B=get(handles.obj_list2,'String');
    C=get(handles.fac_list1,'String');
    D=get(handles.fac_list2,'String');
    F=str2double(get(handles.val,'String'));
    G=get(handles.n_fac,'Value');
    count=1;
    for i=1:size(B,1)
        E=find(strcmp(B(i),A)==1);
            ind_obj(1,count)=E;
            count=count+1;
    end
    count=1;
    for i=1:size(D,1)
        E=find(strcmp(D(i),C)==1);
            ind_fac(1,count)=E;
            count=count+1;
    end
    if H==1
        i_test=1;
    else
        i_test=max(floor(F/100*size(T,1)),1);
    end
    T1=table2array(T);
    ind_train=randperm(size(T1,1));
    ind_test=ind_train(1:i_test);
    ind_train=ind_train(i_test+1:size(T1,1));
    xtrain=T1(ind_train,ind_fac);
    xtest=T1(ind_test,ind_fac);
    ytrain=T1(ind_train,ind_obj+G);
    ytest=T1(ind_test,ind_obj+G);
    t=msgbox('The program is running. Please wait...','modal'); 
%     save 'my_data.mat' 
    delete(findobj(t,'String','OK'));
    delete(findobj(t,'Style','frame'));
    t1=get(t,'CurrentAxes');
    t2=get(t1,'Children');
    set(t2,'FontSize',5);
%     pause(5);
    gp=rungp_jd(A1,B1,C1,D1,xtrain,xtest,ytrain,ytest);
    
    % comparison with gp script
%     gpmodel2mfile(gp,'best','my_results')
%     copyfile('my_results.m','my_results.txt')
%     A=textread('my_results.txt','%s','delimiter','\n');
%     A=char(A(4,1));
%     for i=1:size(D,1)
%         fac1=sprintf('x(:,%d)',i);
%         fac2=char(D(i));
%         A=strrep(A,fac1,fac2);
%     end
%     obj1=char(B);
%     A=strrep(A,'ypred',obj1);
%     fid=fopen('my_model.txt','wt');
%     fprintf(fid,A);
%     fclose(fid);
    
    
    close(t)
%     gp=rungp('my_config');
    ini_eq=gp.results.best.eval_individual;
    par_eq=gp.results.best.returnvalues;
    merge_eq=sprintf('times(%f,%s)',par_eq(2),ini_eq{1});
    for i=2:size(ini_eq,2)
        merge_eq=[merge_eq '+' sprintf('times(%f,%s)',par_eq(i+1),ini_eq{i})];
    end
%     merge_eq=[merge_eq '+' sprintf('%f',par_eq(end))];
% 	count=1;
%     for i=1:size(D,1)
%         x_temp=sprintf('x%d',i);
%         A=strfind(merge_eq,x_temp);
%         if ~isempty(A)
%             xname{count}=x_temp;
%             count=count+1;
%         end
%     end    
    for i=1:size(D,1)
        xname{i}=sprintf('x%d',i);
    end
%     disp(combinedEquation)
    eq=doConversion(merge_eq,['',xname],['',D]);
    eq=sprintf('%s+%f',eq,par_eq(1));
    eq=strrep(eq,'++','+');
    eq=strrep(eq,'+-','-');
    eq=strrep(eq,'-+','-');
    eq=strrep(eq,'--','+');
    
    runtree(gp,'best');
%     gpmodel2mfile(gp,'best','my_results')
%     copyfile('my_results.m','my_results.txt')
%     A=textread('my_results.txt','%s','delimiter','\n');
%     A=char(A(4,1));
%     for i=1:size(D,1)
%         x_new1=sprintf('_x%d_',i);
%         x_new2=sprintf('%s',D{i});
%         eq=regexprep(eq,x_new1,x_new2);         
%     end
%     obj1=char(B);
    eq=sprintf('%s=%s',char(B),eq);
%     A=strrep(A,'ypred',obj1);
    [file,path]=uiputfile('*.txt','Save best model');
    if ~isequal(file,0) || ~isequal(path,0) 
        f=cellstr(fullfile(path,file));
        fid=fopen(char(f),'w');
        fprintf(fid,eq);
        fclose(fid);        
    end
    
%     delete('./my_config.m','./my_results.txt')
%     delete('my_data.mat')
else
    warndlg('The validation and model parameters must be integers.','Error','modal')
end

% hObject    handle to plot_model (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function pop_size_Callback(hObject, eventdata, handles)
% hObject    handle to pop_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pop_size as text
%        str2double(get(hObject,'String')) returns contents of pop_size as a double


% --- Executes during object creation, after setting all properties.
function pop_size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in n_fac.
function n_fac_Callback(hObject, eventdata, handles)
global var_list
A=get(handles.n_fac,'Value');
set(handles.obj_list1,'Value',1);
set(handles.obj_list1,'String',var_list(A+1:end));
set(handles.fac_list1,'Value',1);
set(handles.fac_list1,'String',var_list(1:A));
set(handles.obj_list2,'String','');
set(handles.fac_list2,'String','');
set(handles.add_obj,'Enable','on');
set(handles.rem_obj,'Enable','on');
set(handles.add_fac,'Enable','on');
set(handles.rem_fac,'Enable','on');
set(handles.plot_model,'Enable','off');
set(handles.model_type,'Enable','off');
set(handles.val,'Enable','off');
set(handles.val,'String','');
set(handles.ok_val,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');
% hObject    handle to n_fac (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns n_fac contents as cell array
%        contents{get(hObject,'Value')} returns selected item from n_fac


% --- Executes during object creation, after setting all properties.
function n_fac_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_fac (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ok_val.
function ok_val_Callback(hObject, eventdata, handles)
set(handles.adv_set,'Enable','on');
set(handles.pop_size,'Enable','off');
set(handles.pop_size,'String','');
set(handles.num_gen,'Enable','off');
set(handles.num_gen,'String','');
set(handles.max_gene,'Enable','off');
set(handles.max_gene,'String','');
set(handles.max_dep,'Enable','off');
set(handles.max_dep,'String','');
set(handles.plot_model,'Enable','off');
% hObject    handle to ok_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
