% genetic_algorithm.m is part of CamOptimus.
% 
% CamOptimus is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% CamOptimus is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with CamOptimus.  If not, see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file defines the commands and graphical user interface to set the
% parameters required to perform genetic algorithm.

function varargout = genetic_algorithm(varargin)
% GENETIC_ALGORITHM MATLAB code for genetic_algorithm.fig
%      GENETIC_ALGORITHM, by itself, creates a new GENETIC_ALGORITHM or raises the existing
%      singleton*.
%
%      H = GENETIC_ALGORITHM returns the handle to a new GENETIC_ALGORITHM or the handle to
%      the existing singleton*.
%
%      GENETIC_ALGORITHM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GENETIC_ALGORITHM.M with the given input arguments.
%
%      GENETIC_ALGORITHM('Property','Value',...) creates a new GENETIC_ALGORITHM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before genetic_algorithm_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to genetic_algorithm_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help genetic_algorithm

% Last Modified by GUIDE v2.5 16-Apr-2016 14:10:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @genetic_algorithm_OpeningFcn, ...
                   'gui_OutputFcn',  @genetic_algorithm_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before genetic_algorithm is made visible.
function genetic_algorithm_OpeningFcn(hObject, eventdata, handles, varargin)
global parlist_val
global objlist_val
global par_unit
global ga_par
global objlist
global parlist

hObject.Name='CamOptimus: Genetic Algorithm';
set(handles.a1,'Value',1);
set(handles.par_nam,'Enable','off');
set(handles.par_nam,'String','');
set(handles.a3,'Enable','off');
set(handles.a3,'Value',1);
set(handles.abs_val,'Enable','off');
set(handles.abs_val,'String','');
set(handles.min_val,'Enable','off');
set(handles.min_val,'String','');
set(handles.max_val,'Enable','off');
set(handles.max_val,'String','');
set(handles.a2,'Enable','off'); 
set(handles.a2,'Value',1);
set(handles.unit_abs,'Enable','off');
set(handles.unit_abs,'String','');
set(handles.unit_min,'Enable','off');
set(handles.unit_min,'String','');
set(handles.unit_max,'Enable','off');
set(handles.unit_max,'String','');
set(handles.load_par,'Enable','off');
set(handles.load_exp,'Enable','off');
set(handles.save_scores,'Enable','off');
set(handles.sel_plot,'Enable','off');
set(handles.sel_plot,'Value',1);
set(handles.plot_res,'Enable','off');
set(handles.save_res,'Enable','off');
set(handles.gen_new_exp,'Enable','off');
set(handles.save_new_exp,'Enable','off');
set(handles.a_conv,'Enable','off');
set(handles.ok_conv,'Enable','off');
set(handles.ga_pars,'Enable','off');
set(handles.def_ga,'Enable','off');

set(handles.par_list,'String','');
set(handles.add_par,'Enable','off');
set(handles.rem_par,'Enable','off');
set(handles.obj_nam,'Enable','off');
set(handles.obj_wght,'Enable','off');
set(handles.set_obj,'Enable','off');
set(handles.set_obj,'Value',1);
set(handles.a4,'Value',1);
set(handles.a4,'Enable','off');
set(handles.obj_list,'String','');
set(handles.obj_nam,'String','');
set(handles.obj_wght,'String','1');
set(handles.add_obj,'Enable','off');
set(handles.rem_obj,'Enable','off');
set(handles.gen_exp,'Enable','off');
set(handles.save_par,'Enable','off');
set(handles.save_exp,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.mut_rate,'Enable','off');
set(handles.cross_rate,'Enable','off');
set(handles.nbits,'Enable','off');
set(handles.sel_prob,'Enable','off');
set(handles.mut_rate,'String','');
set(handles.cross_rate,'String','');
set(handles.nbits,'String','');
set(handles.sel_prob,'String','');

set(handles.print_score,'String','');
cla(handles.plot_hist1)
cla(handles.plot_hist2)
title(handles.plot_hist1,{'Average scores for the selected';'objective in each generation'},'FontName','Arial','FontSize',8,'FontWeight','bold')
set(handles.plot_hist1,'FontSize',8)
xlabel(handles.plot_hist1,'Generation number','FontName','Arial','FontSize',8,'FontWeight','bold')
ylabel(handles.plot_hist1,'Average scores','FontName','Arial','FontSize',8,'FontWeight','bold')
title(handles.plot_hist2,{'Population profiling for the selected factor'},'FontName','Arial','FontSize',8,'FontWeight','bold')
set(handles.plot_hist2,'FontSize',8)
xlabel(handles.plot_hist2,'Value','FontName','Arial','FontSize',8,'FontWeight','bold')
ylabel(handles.plot_hist2,'Absolute frequency','FontName','Arial','FontSize',8,'FontWeight','bold')
handles.plot_hist1.XTick=[0:1];
handles.plot_hist1.YTick=[0:1];
handles.plot_hist2.XTick=[0:1];
handles.plot_hist2.YTick=[0:1];
parlist_val=[];
par_unit=[];
objlist_val=[];
ga_par=[];
objlist=[];
objlist_val=[];
parlist=[];

% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to genetic_algorithm (see VARARGIN)

% Choose default command line output for genetic_algorithm
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes genetic_algorithm wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = genetic_algorithm_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function par_nam_Callback(hObject, eventdata, handles)
% hObject    handle to par_nam (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of par_nam as text
%        str2double(get(hObject,'String')) returns contents of par_nam as a double


% --- Executes during object creation, after setting all properties.
function par_nam_CreateFcn(hObject, eventdata, handles)
% hObject    handle to par_nam (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in a3.
function a3_Callback(hObject, eventdata, handles)
global par_unit
global parlist
global parlist_val
% hObject    handle to a3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a3

A=get(handles.a3,'Value');
%par_unit=[];
%parlist=[];
%parlist_val=[];
set(handles.min_val,'String','');
set(handles.max_val,'String','');
set(handles.unit_min,'String','');
set(handles.unit_max,'String','');
set(handles.abs_val,'String','');
set(handles.unit_abs,'String','');
set(handles.par_nam,'String','');
set(handles.par_nam,'Enable','on');
set(handles.add_par,'Enable','on');
set(handles.rem_par,'Enable','on');

if A==1
    set(handles.abs_val,'Enable','off');
    set(handles.unit_abs,'Enable','off');
    set(handles.min_val,'Enable','on');
    set(handles.max_val,'Enable','on');
    set(handles.unit_min,'Enable','on');
    set(handles.unit_max,'Enable','on');    
else
    set(handles.abs_val,'Enable','on');
    set(handles.unit_abs,'Enable','on');
    set(handles.min_val,'Enable','off');
    set(handles.max_val,'Enable','off');
    set(handles.unit_min,'Enable','off');
    set(handles.unit_max,'Enable','off');     
end
%set(handles.a3,'Enable','off'); 

% --- Executes during object creation, after setting all properties.
function a3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function abs_val_Callback(hObject, eventdata, handles)
% hObject    handle to abs_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of abs_val as text
%        str2double(get(hObject,'String')) returns contents of abs_val as a double


% --- Executes during object creation, after setting all properties.
function abs_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to abs_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function min_val_Callback(hObject, eventdata, handles)
% hObject    handle to min_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of min_val as text
%        str2double(get(hObject,'String')) returns contents of min_val as a double


% --- Executes during object creation, after setting all properties.
function min_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to min_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function max_val_Callback(hObject, eventdata, handles)
% hObject    handle to max_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of max_val as text
%        str2double(get(hObject,'String')) returns contents of max_val as a double


% --- Executes during object creation, after setting all properties.
function max_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to max_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in par_list.
function par_list_Callback(hObject, eventdata, handles)
global parlist
global parlist_val
global par_unit

% hObject    handle to par_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns par_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from par_list
A=get(handles.par_list,'Value');
B=get(handles.a3,'Value');
C=get(handles.add_par,'Enable');

if parlist_val(A,1)==parlist_val(A,2)
    set(handles.min_val,'Enable','off');
    set(handles.max_val,'Enable','off');
    set(handles.unit_min,'Enable','off');
    set(handles.unit_max,'Enable','off');    
    set(handles.min_val,'String','');
    set(handles.max_val,'String','');
    set(handles.unit_min,'String','');
    set(handles.unit_max,'String','');
    if strcmp(C,'on')==1
        set(handles.abs_val,'Enable','on');
        set(handles.unit_abs,'Enable','on');
    end
    set(handles.par_nam,'String',parlist(A));
    set(handles.abs_val,'String',parlist_val(A,1));
    set(handles.unit_abs,'String',par_unit{A});
    set(handles.a3,'Value',2);
else
    if strcmp(C,'on')==1
        set(handles.min_val,'Enable','on');
        set(handles.max_val,'Enable','on');
        set(handles.unit_min,'Enable','on');
        set(handles.unit_max,'Enable','on');
    end
    set(handles.abs_val,'String','');
    set(handles.unit_abs,'String','');
    set(handles.abs_val,'Enable','off');
    set(handles.unit_abs,'Enable','off');
    set(handles.min_val,'String',parlist_val(A,1));
    set(handles.max_val,'String',parlist_val(A,2));
    set(handles.unit_min,'String',par_unit{A});
    set(handles.unit_max,'String',par_unit{A});    
    set(handles.par_nam,'String',parlist(A));
    set(handles.a3,'Value',1); 
end
    

% --- Executes during object creation, after setting all properties.
function par_list_CreateFcn(hObject, eventdata, handles)

% hObject    handle to par_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in add_par.
function add_par_Callback(hObject, eventdata, handles)
global parlist
global par_unit
global parlist_val
% hObject    handle to add_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A=get(handles.par_nam,'String');
A=regexprep(A,'[^a-zA-Z0-9]','_');
A1=get(handles.unit_abs,'String');
A1=regexprep(A1,'[^a-zA-Z0-9]','_');
A2=get(handles.unit_min,'String');
A2=regexprep(A2,'[^a-zA-Z0-9]','_');
A3=get(handles.unit_max,'String');
A3=regexprep(A3,'[^a-zA-Z0-9]','_');
B=get(handles.a3,'Value');
C=str2double(get(handles.abs_val,'String'));
D=str2double(get(handles.min_val,'String'));
E=str2double(get(handles.max_val,'String'));
F=get(handles.par_list,'Value');
G=cell(get(handles.par_list,'String'));

if B==1
    H=strcmp(A2,A3);
    if H==1
        if and(and(and(and(and(and(and(~isempty(A),isnumeric(D)),~isempty(A)),isnumeric(D)),isnumeric(E)),E>D),~isnan(D)),~isnan(E))
            G_temp=[G;A];
            if size(unique(G_temp),1)==size(G_temp,1)
                G=G_temp;
                set(handles.par_list,'String',G);
                set(handles.par_list,'Value',size(G,1));
                parlist_val(size(G,1),:)=[D E];
                par_unit{size(G,1)}=A2;
                
            else
                parlist_val(F,:)=[D E];
                par_unit{F}=A2;
                %disp(parlist_val)
            end
            parlist=G;
        else
            %         disp(B)
            warndlg('The minimum and maximum values must be numeric and the minimum value must be equal or lower than the maximum value.','Error','modal')
        end
    else
        warndlg('The units of the factors must be consistent.','Error','modal')
    end
else
    if and(and(and(~isempty(A),isnumeric(C)),~isnan(C)),~isempty(A1))
        G_temp=[G;A];
        if size(unique(G_temp),1)==size(G_temp,1)
            G=G_temp;
            set(handles.par_list,'String',G);
            set(handles.par_list,'Value',size(G,1));
            parlist_val(size(G,1),:)=[C C];
            par_unit{size(G,1)}=A1;
        else
            parlist_val(F,:)=[C C];
            par_unit{F}=A1;
            %disp(parlist_val)
        end
        parlist=G;
        set(handles.adv_set,'Enable','on');
    else
%         disp(B)
        warndlg('The absolute value must be numeric and the units of the factor must be valid.','Error')        
    end    
end
set(handles.adv_set,'Enable','on');
set(handles.adv_set,'Value',1);
set(handles.mut_rate,'Enable','off');
set(handles.cross_rate,'Enable','off');
set(handles.nbits,'Enable','off');
set(handles.sel_prob,'Enable','off');
set(handles.mut_rate,'String','');
set(handles.cross_rate,'String','');
set(handles.nbits,'String','');
set(handles.sel_prob,'String','');
set(handles.ga_pars,'Enable','off');
set(handles.def_ga,'Enable','off');
set(handles.gen_exp,'Enable','off');
set(handles.save_par,'Enable','off');
set(handles.save_exp,'Enable','off');
% --- Executes on button press in rem_par.
function rem_par_Callback(hObject, eventdata, handles)
global par_unit
global parlist
global parlist_val
% hObject    handle to rem_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

A=cell(get(handles.par_list,'String'));
B=get(handles.par_list,'Value');
C=get(handles.a3,'Value');

if ~isempty(A)
    A(B,:)=[];
    par_unit(B)=[];
    parlist=A;
    parlist_val(B,:)=[];       
    if isempty(A)
        set(handles.adv_set,'Enable','off');
        set(handles.par_list,'Value',1);
        set(handles.par_list,'String','');        
        set(handles.par_nam,'String','');
        set(handles.min_val,'String','');
        set(handles.max_val,'String','');
        set(handles.unit_min,'String','');
        set(handles.unit_max,'String','');
        set(handles.abs_val,'String','');
        set(handles.unit_abs,'String','');
    else
        if B==1
            D=1;
        elseif B>1
            D=B-1;
        end
        set(handles.par_nam,'String',parlist{D});
        set(handles.par_list,'Value',D);
        set(handles.par_list,'String',A);
        if C==1
            set(handles.min_val,'String',parlist_val(D,1));
            set(handles.max_val,'String',parlist_val(D,2));
            set(handles.unit_min,'String',par_unit{D});
            set(handles.unit_max,'String',par_unit{D});
        elseif C==2
            set(handles.abs_val,'String',parlist_val(D,1));
            set(handles.unit_abs,'String',par_unit{D});
        end
    end
end
if isempty(A)
    set(handles.adv_set,'Enable','off');    
else
    set(handles.adv_set,'Enable','on');    
end
set(handles.adv_set,'Value',1);
set(handles.mut_rate,'Enable','off');
set(handles.cross_rate,'Enable','off');
set(handles.nbits,'Enable','off');
set(handles.sel_prob,'Enable','off');
set(handles.mut_rate,'String','');
set(handles.cross_rate,'String','');
set(handles.nbits,'String','');
set(handles.sel_prob,'String','');
set(handles.ga_pars,'Enable','off');
set(handles.def_ga,'Enable','off');
set(handles.gen_exp,'Enable','off');
set(handles.save_par,'Enable','off');
set(handles.save_exp,'Enable','off');

% --- Executes on selection change in set_obj.
function set_obj_Callback(hObject, eventdata, handles)
% hObject    handle to set_obj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns set_obj contents as cell array
%        contents{get(hObject,'Value')} returns selected item from set_obj


% --- Executes during object creation, after setting all properties.
function set_obj_CreateFcn(hObject, eventdata, handles)
% hObject    handle to set_obj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function obj_nam_Callback(hObject, eventdata, handles)
% hObject    handle to obj_nam (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of obj_nam as text
%        str2double(get(hObject,'String')) returns contents of obj_nam as a double


% --- Executes during object creation, after setting all properties.
function obj_nam_CreateFcn(hObject, eventdata, handles)
% hObject    handle to obj_nam (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in obj_list.
function obj_list_Callback(hObject, eventdata, handles)
global objlist
global objlist_val
A=get(handles.obj_list,'Value');
B=get(handles.a4,'Value');
set(handles.obj_nam,'String',objlist(A));
set(handles.obj_wght,'String',objlist_val(A,2));
set(handles.set_obj,'Value',objlist_val(A,1));
%if B==1
%    set(handles.a4,'Enable','on');
%else
%    set(handles.a4,'Enable','off');
%end
% hObject    handle to obj_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns obj_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from obj_list


% --- Executes during object creation, after setting all properties.
function obj_list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to obj_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in add_obj.
function add_obj_Callback(hObject, eventdata, handles)
global objlist
global objlist_val
A=get(handles.obj_nam,'String');
A=regexprep(A,'[^a-zA-Z0-9]','_');
B=cell(get(handles.obj_list,'String'));
C=get(handles.set_obj,'Value');
D=get(handles.obj_list,'Value');
E=str2double(get(handles.obj_wght,'String'));
F=get(handles.a4,'Value');

if and(and(~isempty(A),isnumeric(E)),~isnan(E))
    B_temp=[B;A];
    if size(unique(B_temp),1)==size(B_temp,1)
        set(handles.obj_list,'String',B_temp);
        set(handles.obj_list,'Value',size(B_temp,1));
        if F==2
            objlist_val(size(B_temp,1),:)=[C E];
        elseif F==1
            objlist_val(size(B_temp,1),:)=[C 1];
            set(handles.obj_wght,'String',1);
        end
        B=B_temp;
    else
        if F==2
            objlist_val(D,:)=[C E];
        elseif F==1
            objlist_val(D,:)=[C 1];
            set(handles.obj_wght,'String',1); 
        end        
        %disp(objlist_val)
        
    end
    objlist=B;
else
	warndlg('The objective weight must be numeric.','Error','modal')
end
if ~isempty(A)
	set(handles.a2,'Enable','on');  
end
% hObject    handle to add_obj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rem_obj.
function rem_obj_Callback(hObject, eventdata, handles)
global objlist
global objlist_val
% hObject    handle to rem_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A=cell(get(handles.obj_list,'String'));
B=get(handles.obj_list,'Value');
C=get(handles.a4,'Value');

if ~isempty(A)
    A(B,:)=[];
    objlist=A;
    objlist_val(B,:)=[];       
    if isempty(A)
        set(handles.obj_list,'Value',1);
        set(handles.obj_list,'String','');        
        set(handles.obj_nam,'String','');
        if C==1
            set(handles.obj_wght,'String',1);
        else
            set(handles.obj_wght,'String','');
        end
    else
        if B==1
            D=1;
        elseif B>1
            D=B-1;
        end
        set(handles.obj_nam,'String',objlist{D});
        set(handles.obj_list,'Value',D);
        set(handles.obj_list,'String',A);
        set(handles.obj_wght,'String',objlist_val(D,1));
    end
end
if isempty(A)
	set(handles.a2,'Enable','off');   
end

% hObject    handle to rem_obj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in gen_exp.
function gen_exp_Callback(hObject, eventdata, handles)
global parlist_val
global pinitial
ga_par(1,1)=str2num(get(handles.mut_rate,'String'));
ga_par(1,2)=str2num(get(handles.cross_rate,'String'));
ga_par(1,3)=str2num(get(handles.nbits,'String'));
ga_par(1,4)=str2num(get(handles.sel_prob,'String')); 
pinitial=firstmedium(parlist_val,ga_par);
set(handles.save_par,'Enable','on');
set(handles.save_exp,'Enable','off');
warndlg('Now you can save your factors and experiments.','Done','modal')
%pinitial
% hObject    handle to gen_exp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in a1.
function a1_Callback(hObject, eventdata, handles)
global parlist_val
global objlist_val
global par_unit
global ga_par
global objlist
global parlist
A=get(handles.a1,'Value');
if A==1
    set(handles.a4,'Enable','on');
    set(handles.load_par,'Enable','off');
elseif A==2
    set(handles.a4,'Enable','off');
    set(handles.load_par,'Enable','on');
%     set(handles.a4,'Enable','off');    
end
set(handles.par_nam,'Enable','off');
set(handles.par_nam,'String','');
set(handles.a3,'Enable','off');
set(handles.a3,'Value',1);
set(handles.abs_val,'Enable','off');
set(handles.abs_val,'String','');
set(handles.min_val,'Enable','off');
set(handles.min_val,'String','');
set(handles.max_val,'Enable','off');
set(handles.max_val,'String','');
set(handles.a2,'Enable','off'); 
set(handles.a2,'Value',1);
set(handles.unit_abs,'Enable','off');
set(handles.unit_abs,'String','');
set(handles.unit_min,'Enable','off');
set(handles.unit_min,'String','');
set(handles.unit_max,'Enable','off');
set(handles.unit_max,'String','');
set(handles.load_exp,'Enable','off');
set(handles.save_scores,'Enable','off');
set(handles.sel_plot,'Enable','off');
set(handles.sel_plot,'Value',1);
set(handles.plot_res,'Enable','off');
set(handles.save_res,'Enable','off');
set(handles.gen_new_exp,'Enable','off');
set(handles.save_new_exp,'Enable','off');
set(handles.a_conv,'Enable','off');
set(handles.ok_conv,'Enable','off');
set(handles.ga_pars,'Enable','off');
set(handles.def_ga,'Enable','off');

set(handles.par_list,'String','');
set(handles.add_par,'Enable','off');
set(handles.rem_par,'Enable','off');
set(handles.obj_nam,'Enable','off');
set(handles.obj_wght,'Enable','off');
set(handles.set_obj,'Enable','off');
set(handles.set_obj,'Value',1);
set(handles.a4,'Value',1);
set(handles.obj_list,'String','');
set(handles.obj_nam,'String','');
set(handles.obj_wght,'String','1');
set(handles.add_obj,'Enable','off');
set(handles.rem_obj,'Enable','off');
set(handles.gen_exp,'Enable','off');
set(handles.save_par,'Enable','off');
set(handles.save_exp,'Enable','off');
set(handles.adv_set,'Enable','off');
set(handles.mut_rate,'Enable','off');
set(handles.cross_rate,'Enable','off');
set(handles.nbits,'Enable','off');
set(handles.sel_prob,'Enable','off');
set(handles.mut_rate,'String','');
set(handles.cross_rate,'String','');
set(handles.nbits,'String','');
set(handles.sel_prob,'String','');

set(handles.print_score,'String','');
cla(handles.plot_hist1)
cla(handles.plot_hist2)
parlist_val=[];
par_unit=[];
ga_par=[];
objlist=[];
objlist_val=[];
parlist=[];

% hObject    handle to a1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a1


% --- Executes during object creation, after setting all properties.
function a1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in save_par.
function save_par_Callback(hObject, eventdata, handles)
global parlist_val
global parlist
global objlist
global objlist_val
global par_unit
A=get(handles.adv_set,'Value');
ga_par=zeros(1,4);
if A==1
    ga_par(1,1)=str2num(get(handles.mut_rate,'String'));
    ga_par(1,2)=str2num(get(handles.cross_rate,'String'));
    ga_par(1,3)=str2num(get(handles.nbits,'String'));
    ga_par(1,4)=str2num(get(handles.sel_prob,'String'));
else
    ga_par(1,1)=0.01;
    ga_par(1,2)=0.9;
    ga_par(1,3)=5;
    ga_par(1,4)=0.5;
end
% set(handles.cross_rate,'String','0.9');
% set(handles.nbits,'String','5');

%uisave({'parlist_val','objlist','objlist_val','parlist'})
[file,path]=uiputfile('*.mat','Save Factors');
if ~isequal(file,0) || ~isequal(path,0) 
    f=cellstr(fullfile(path,file));
    eval(sprintf('save ''%s'' parlist_val objlist objlist_val parlist par_unit ga_par',char(f)))
    set(handles.save_exp,'Enable','on');
end

% hObject    handle to save_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in save_exp.
function save_exp_Callback(hObject, eventdata, handles)
global parlist
global pinitial
global objlist
global objlist_val
global par_unit

%pinitial
[file,path]=uiputfile('*.xls','Save Experiments');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    if exist(f)
        delete(f)
    end
%     fid=fopen(f,'wt');
    for i=1:size(parlist,1)
        parlist1{i}=sprintf('%s_%s',parlist{i},par_unit{i});
    end
    for i=1:size(objlist,1)
        if objlist_val(i,1)==1
            objlist1{i}=sprintf('%s_%d_%s',objlist{i},objlist_val(i,2),'max');
        elseif objlist_val(i,1)==2
            objlist1{i}=sprintf('%s_%d_%s',objlist{i},objlist_val(i,2),'min');
        end
    end    
%     fprintf(fid,'\n');
%     for i=1:size(pinitial,1)
%         fprintf(fid,'Experiment %d',i);
%         for j=1:size(parlist,1)
%             fprintf(fid,'\t%.3f',pinitial(i,j));
%         end
%         fprintf(fid,'\n');
%     end
%     fclose(fid);
     for i=1:size(pinitial,1)
         eval(sprintf('RowName{%d}=''Experiment 1.%d'';',i,i))
     end
     f=fullfile(path,file);
     T=array2table([pinitial zeros(size(pinitial,1),size(objlist,1))]);%,'RowNames',RowName,'VariableNames',
     T=[RowName' T];
     parlist1=regexprep(parlist1,'[^a-zA-Z0-9]','_');
     objlist1=regexprep(objlist1,'[^a-zA-Z0-9]','_');
     T.Properties.VariableNames=['Factors' parlist1 objlist1];
%     
     %

%works in windows
writetable(T,f,'WriteVariableNames',true,'WriteRowNames',true);%,'Sheet','Generation 1','Delimiter','tab','FileType','spreadsheet','Range','A1'
%writetable(A,f'Delimiter','tab')
% e=actxserver('Excel.Application'); % # open Activex server
% ewb=e.Workbooks.Open(f); % # open file (enter full path!)
% ewb.Worksheets.Item(1).Name='Generation 1';
% ran=e.Activesheet.get('Range','A1');
% ran.value='Parameters';
% ewb.Save
% ewb.Close(false)
% e.Quit


% T=readtable(f,'ReadRowNames',true,'ReadVariableNames',true);


% [status,sheets] = xlsfinfo(f);
% numOfSheets=numel(sheets);
end

% hObject    handle to save_exp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4


% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function unit_abs_Callback(hObject, eventdata, handles)
% hObject    handle to unit_abs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of unit_abs as text
%        str2double(get(hObject,'String')) returns contents of unit_abs as a double


% --- Executes during object creation, after setting all properties.
function unit_abs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to unit_abs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function unit_min_Callback(hObject, eventdata, handles)
% hObject    handle to unit_min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of unit_min as text
%        str2double(get(hObject,'String')) returns contents of unit_min as a double


% --- Executes during object creation, after setting all properties.
function unit_min_CreateFcn(hObject, eventdata, handles)
% hObject    handle to unit_min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function unit_max_Callback(hObject, eventdata, handles)
% hObject    handle to unit_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of unit_max as text
%        str2double(get(hObject,'String')) returns contents of unit_max as a double


% --- Executes during object creation, after setting all properties.
function unit_max_CreateFcn(hObject, eventdata, handles)
% hObject    handle to unit_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in a2.
function a2_Callback(hObject, eventdata, handles)
A=get(handles.a2,'Value');
set(handles.par_list,'Value',1);
set(handles.par_list,'String','');
if A==1
    set(handles.a3,'Enable','on');
    set(handles.a3,'Value',1);
    set(handles.min_val,'Enable','off');
    set(handles.max_val,'Enable','off');
    set(handles.unit_min,'Enable','off');
    set(handles.unit_max,'Enable','off');
    set(handles.par_nam,'Enable','off');    
    set(handles.add_par,'Enable','off');
    set(handles.rem_par,'Enable','off');         
else
    set(handles.a3,'Enable','off');
    set(handles.a3,'Value',1);
    set(handles.min_val,'Enable','on');
    set(handles.min_val,'String','');
    set(handles.max_val,'Enable','on');
    set(handles.max_val,'String','');
    set(handles.unit_min,'Enable','on');
    set(handles.unit_min,'String','');
    set(handles.unit_max,'Enable','on');
    set(handles.unit_max,'String','');    
    set(handles.par_nam,'Enable','on');   
    set(handles.add_par,'Enable','on');
    set(handles.rem_par,'Enable','on');      
end
set(handles.par_nam,'String','');   
set(handles.adv_set,'Enable','off');
set(handles.mut_rate,'Enable','off');
set(handles.cross_rate,'Enable','off');
set(handles.nbits,'Enable','off');
set(handles.sel_prob,'Enable','off');
set(handles.mut_rate,'String','');
set(handles.cross_rate,'String','');
set(handles.nbits,'String','');
set(handles.sel_prob,'String',''); 
set(handles.ga_pars,'Enable','off');
set(handles.adv_set,'Value',1);
set(handles.def_ga,'Enable','off');
set(handles.gen_exp,'Enable','off');
set(handles.save_par,'Enable','off');
set(handles.save_exp,'Enable','off');
% hObject    handle to a2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a2


% --- Executes during object creation, after setting all properties.
function a2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function obj_wght_Callback(hObject, eventdata, handles)
% hObject    handle to obj_wght (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of obj_wght as text
%        str2double(get(hObject,'String')) returns contents of obj_wght as a double


% --- Executes during object creation, after setting all properties.
function obj_wght_CreateFcn(hObject, eventdata, handles)
% hObject    handle to obj_wght (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in a4.
function a4_Callback(hObject, eventdata, handles)
global objlist_val
A=get(handles.a4,'Value');
set(handles.obj_nam,'Enable','on');
set(handles.obj_nam,'String','');
set(handles.add_par,'Enable','off');
set(handles.rem_par,'Enable','off');
set(handles.set_obj,'Enable','on');
set(handles.a2,'Enable','off');
set(handles.a3,'Enable','off');
set(handles.gen_exp,'Enable','off');
set(handles.save_par,'Enable','off');
set(handles.save_exp,'Enable','off');
set(handles.min_val,'Enable','off');
set(handles.max_val,'Enable','off');
set(handles.unit_min,'Enable','off');
set(handles.unit_max,'Enable','off');
set(handles.par_nam,'Enable','off');
set(handles.abs_val,'Enable','off');
set(handles.unit_abs,'Enable','off');
set(handles.par_nam,'String','');
set(handles.abs_val,'String','');
set(handles.min_val,'String','');
set(handles.max_val,'String','');
set(handles.unit_abs,'String','');
set(handles.unit_min,'String','');
set(handles.unit_max,'String','');
set(handles.par_list,'String','');
set(handles.par_list,'Value',1);
set(handles.set_obj,'Value',1);
set(handles.add_obj,'Enable','on');
set(handles.rem_obj,'Enable','on');
set(handles.obj_list,'String','');
set(handles.adv_set,'Enable','off');
set(handles.mut_rate,'Enable','off');
set(handles.cross_rate,'Enable','off');
set(handles.ga_pars,'Enable','off');
set(handles.adv_set,'Value',1);
set(handles.def_ga,'Enable','off');
set(handles.nbits,'Enable','off');
set(handles.sel_prob,'Enable','off');
set(handles.mut_rate,'String','');
set(handles.cross_rate,'String','');
set(handles.nbits,'String','');
set(handles.sel_prob,'String','');

if A==1
	objlist_val(:,2)=1;
	set(handles.obj_wght,'String',1);
    set(handles.obj_wght,'Enable','off');
else
	set(handles.obj_wght,'String','');
    set(handles.obj_wght,'Enable','on');    
end  
% hObject    handle to a4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a4


% --- Executes during object creation, after setting all properties.
function a4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in load_par.
function load_par_Callback(hObject, eventdata, handles)
global objlist
global objlist_val
global parlist
global parlist_val
global par_unit
global ga_par

[file,path]=uigetfile('*.mat','Load Factors');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    load(f)
    A=size(unique(objlist_val(:,1)),1);
    if A==1
        set(handles.a4,'Value',1);
    else
        set(handles.a4,'Value',2);
    end
    set(handles.min_val,'Enable','off');
    set(handles.max_val,'Enable','off');
    set(handles.unit_min,'Enable','off');
    set(handles.unit_max,'Enable','off');
    set(handles.unit_abs,'Enable','off');
    set(handles.abs_val,'Enable','off');
    set(handles.par_nam,'Enable','off');
    set(handles.add_obj,'Enable','off');
    set(handles.rem_obj,'Enable','off');
    set(handles.gen_exp,'Enable','off');
    set(handles.save_par,'Enable','off');
    set(handles.save_exp,'Enable','off');
    set(handles.ga_pars,'Enable','off');
    set(handles.def_ga,'Enable','off');
    set(handles.obj_nam,'Enable','off');
    set(handles.obj_wght,'Enable','off');
    set(handles.set_obj,'Enable','off');
    set(handles.load_exp,'Enable','on');
    set(handles.save_res,'Enable','off');
    set(handles.gen_new_exp,'Enable','off');
    set(handles.save_new_exp,'Enable','off');
    set(handles.a_conv,'Enable','off');
    set(handles.ok_conv,'Enable','off');
    set(handles.abs_val,'String','');
    set(handles.unit_abs,'String','');
    set(handles.par_nam,'String','');
    set(handles.par_list,'String',parlist);
    set(handles.par_list,'Value',1);
    set(handles.min_val,'String',parlist_val(1,1));
    set(handles.max_val,'String',parlist_val(1,2));
    set(handles.unit_min,'String',par_unit{1});
    set(handles.unit_max,'String',par_unit{1});
    set(handles.par_list,'String',parlist);
    set(handles.par_nam,'String',parlist{1});
    set(handles.mut_rate,'String',ga_par(1,1));
    set(handles.cross_rate,'String',ga_par(1,2));
    set(handles.nbits,'String',ga_par(1,3));
    set(handles.sel_prob,'String',ga_par(1,4));   
    set(handles.a4,'Enable','off');
    set(handles.obj_list,'Value',1);
    set(handles.obj_list,'String',objlist);
    set(handles.obj_nam,'String',objlist{1});
    set(handles.obj_wght,'String',objlist_val(1,1));
    set(handles.print_score,'String','');
    set(handles.plot_res,'Enable','off');
    set(handles.save_res,'Enable','off');
    set(handles.save_scores,'Enable','off');
    set(handles.sel_plot,'Enable','off');
    set(handles.sel_plot,'Value',1);
    cla(handles.plot_hist1)
    cla(handles.plot_hist2)
end

% hObject    handle to load_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in load_exp.
function load_exp_Callback(hObject, eventdata, handles)
global objlist
global parlist_val
global parlist
global usedVals
global repl
global n_exp
global T

[file,path]=uigetfile('*.xls','Load Experiments');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    T=readtable(f,'ReadRowNames',true);%
    npars=size(parlist,1);
    nobjs=size(objlist,1);
    % ind_var=find(parlist_val(:,1)-parlist_val(:,2)~=0);
    var_par=find(parlist_val(:,1)~=parlist_val(:,2));
    n_exp=2*size(var_par,1)-2;
    ngen=size(T,1)/n_exp;
    % the user will provide the median values
    usedVals=[];
    repl=[];
    for i=1:ngen
        usedVals{i}=table2array(T((i-1)*n_exp+1:i*n_exp,1:npars));
        repl{i}=table2array(T((i-1)*n_exp+1:i*n_exp,npars+1:npars+nobjs));
    end
    set(handles.plot_res,'Enable','on');
    set(handles.save_res,'Enable','off');
    set(handles.a_conv,'Enable','off');
    set(handles.ok_conv,'Enable','off');
    set(handles.gen_new_exp,'Enable','off');
    set(handles.save_new_exp,'Enable','off');
    set(handles.save_scores,'Enable','off');
    set(handles.sel_plot,'Enable','on');
    set(handles.sel_plot,'Value',1);
end

% hObject    handle to load_exp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in plot_res.
function plot_res_Callback(hObject, eventdata, handles)
global objlist_val
global objlist
global parlist_val
global usedVals
global repl
global ga_par
global pars_hist
global idx_sort
global nbins
A=get(handles.par_list,'Value');
B=get(handles.sel_plot,'Value');
C=get(handles.obj_list,'Value');

[Score_o,Score_sort,idx_sort]=calc_score(usedVals,repl,parlist_val,objlist_val,ga_par);
cross_rate=ga_par(1,2);
nbits=ga_par(1,3);
sel_prob=ga_par(1,4);
nbins=2^nbits;
pars_hist=[];
var_par=find(parlist_val(:,1)~=parlist_val(:,2));
n_exp=2*size(var_par,1)-2;
n_sel=ceil(n_exp*sel_prob);
range=[parlist_val(A,1)-(parlist_val(A,2)-parlist_val(A,1))/(nbins-1):(parlist_val(A,2)-parlist_val(A,1))/(nbins-1):parlist_val(A,2)+(parlist_val(A,2)-parlist_val(A,1))/(nbins-1)];
for i=1:size(usedVals,2)
    scores_mean(i)=mean(Score_o{i}(C,:));
    scores_std(i)=std(Score_o{i}(C,:));
end
cla(handles.plot_hist1)

bar(handles.plot_hist1,1:size(scores_mean,2),abs(scores_mean))
hold on
errorbar(handles.plot_hist1,1:size(scores_mean,2),abs(scores_mean),abs(scores_std),'r.')
title(handles.plot_hist1,{'Average scores for the selected';'objective in each generation'},'FontName','Arial','FontSize',8,'FontWeight','bold')
xlabel(handles.plot_hist1,'Generation number','FontName','Arial','FontSize',8,'FontWeight','bold')
ylabel(handles.plot_hist1,'Average scores','FontName','Arial','FontSize',8,'FontWeight','bold')
set(handles.plot_hist1,'FontSize',8)
% for i=1:size(objlist,1)
%     obj_scores{i,1}=sprintf('%s (score=%0.2f)',objlist{i},mean(Score(idx_sort(1:n_sel),i)));
% end
% set(handles.obj_list,'String',obj_scores);
% pars_hist_end=usedVals{end}(idx_sort{end}(1:n_sel),A);
% pars_hist_end=round(pars_hist_end,4);
cla(handles.plot_hist2)

if B==1
    for i=1:size(usedVals,2)
        pars_hist=usedVals{i}(:,A)+0.0001;
        [N(i,:),X]=histcounts(pars_hist,range(1,2:end));
    end    
    bar(handles.plot_hist2,X(1:end-1)',N')    
    title(handles.plot_hist2,{'Population profiling for the selected factor'},'FontName','Arial','FontSize',8,'FontWeight','bold')
    xlabel(handles.plot_hist2,'Value','FontName','Arial','FontSize',8,'FontWeight','bold')
    ylabel(handles.plot_hist2,'Absolute frequency','FontName','Arial','FontSize',8,'FontWeight','bold')
else
    % hist(handles.plot_hist2,pars_hist,nbins)
    
    % if max(size(unique(pars_hist_end)))==1
    %     pars_hist_end=unique(pars_hist_end);
    % end
    % hist(handles.plot_hist2,pars_hist_end,nbins)
    pars_hist=usedVals{end}(idx_sort{end}(1:n_sel),A)+0.0001;
    [N,X]=histcounts(pars_hist,range(1,2:end));
    bar(handles.plot_hist2,X(1,1:end-1),N)
    title(handles.plot_hist2,{'Best performing fraction in the last generation'},'FontName','Arial','FontSize',8,'FontWeight','bold')
    xlabel(handles.plot_hist2,'Value','FontName','Arial','FontSize',8,'FontWeight','bold')
    ylabel(handles.plot_hist2,'Absolute frequency','FontName','Arial','FontSize',8,'FontWeight','bold')
end
set(handles.plot_hist2,'ytick',0:max(max(N)))
% if and(length(unique(pars_hist))>1,length(unique(pars_hist_end))>1)
%     min_hist=min(min(pars_hist))-0.05*min(min(pars_hist));
%     max_hist=max(max(pars_hist))+0.05*min(min(pars_hist));
%     
% end
xlim(handles.plot_hist2,[range(1,1) range(1,end)])
set(handles.save_scores,'Enable','on');
set(handles.save_res,'Enable','off');
set(handles.a_conv,'Enable','off');
set(handles.ok_conv,'Enable','off');
set(handles.gen_new_exp,'Enable','off');
set(handles.save_new_exp,'Enable','off');
% label=strrep(objlist{i},'_',' ');
% xlabel(label,'FontName','Arial','FontSize',12,'FontWeight','bold')
% ylabel('Frequency','FontName','Arial','FontSize',12,'FontWeight','bold')
% 
% bar(handles.plot_hist1,1:size(repl,2),mean_score');
% title('Score performance over generations','FontName','Arial','FontSize',12,'FontWeight','bold')
% ylabel(handles.plot_hist1,'Average scores','FontName','Arial','FontSize',12,'FontWeight','bold')
% xlabel(handles.plot_hist1,'Generation Number','FontName','Arial','FontSize',10,'FontWeight','bold')
% handles.plot_hist1.XTick=[1:size(repl,2)];
% set(handles.a_conv,'Enable','on');
% set(handles.ok_conv,'Enable','on');
% set(handles.gen_new_exp,'Enable','off');
% set(handles.save_new_exp,'Enable','off');
% for i=1:size(objlist,1)
%     obj_scores{i,1}=sprintf('%s (score in last generation=%0.2f)',objlist{i},mean(Score_ind(1,i)));
% end
% figure
% title('Frequency of the factor values in the selected values for the last generations','FontName','Arial','FontSize',12,'FontWeight','bold')
% for i=1:size(objlist,1)
%     repl_hist=repl{end}(1:size(repl{end},1),i);
%     subplot(size(objlist,1),1,i)
%     hist(repl_hist,nbins)
%     label=strrep(objlist{i},'_',' ');
%     xlabel(label,'FontName','Arial','FontSize',12,'FontWeight','bold')
%     ylabel('Frequency','FontName','Arial','FontSize',12,'FontWeight','bold')
% end
% figure
% title('Frequency of the factor values over the generations','FontName','Arial','FontSize',12,'FontWeight','bold')


% save figure without plotting
% figure('Visible','off')
% plot(1:100)
% saveas(gcf,'file.fig','fig')
% 
% openfig('file.fig','new','visible')


% set(handles.obj_list,'String',obj_scores);
% hObject    handle to plot_res (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in a_conv.
function a_conv_Callback(hObject, eventdata, handles)
% hObject    handle to a_conv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a_conv contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a_conv


% --- Executes during object creation, after setting all properties.
function a_conv_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a_conv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ok_conv.
function ok_conv_Callback(hObject, eventdata, handles)
A=get(handles.a_conv,'Value');
if A==1
    set(handles.gen_new_exp,'Enable','on');
    set(handles.save_new_exp,'Enable','off');
elseif A==2
    warndlg('You have completed the optimisation process. Thank you for using CamOptimus.','Done','modal')
end
% hObject    handle to ok_conv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in gen_new_exp.
function gen_new_exp_Callback(hObject, eventdata, handles)
global objlist_val
global parlist_val
global usedVals
global repl
global pnew
global ga_par

pnew=thirdmedium_new(usedVals,repl,parlist_val,objlist_val,ga_par);
set(handles.save_new_exp,'Enable','on');
warndlg('Now you can save your new experiments.','Done','modal')
% hObject    handle to gen_new_exp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in save_new_exp.
function save_new_exp_Callback(hObject, eventdata, handles)
global T
global pnew
global objlist
global repl
global parlist
global par_unit
global objlist_val

[file,path]=uiputfile('*.xls','Save Experiments');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    if exist(f)
        delete(f)
    end    
    for i=1:size(parlist,1)
        parlist1{i}=sprintf('%s_%s',parlist{i},par_unit{i});
    end
    for i=1:size(objlist,1)
        if objlist_val(i,1)==1
            objlist1{i}=sprintf('%s_%d_%s',objlist{i},objlist_val(i,2),'max');
        elseif objlist_val(i,1)==2
            objlist1{i}=sprintf('%s_%d_%s',objlist{i},objlist_val(i,2),'min');
        end
    end
    Told=table2array(T);
    RowName_old=T.Properties.RowNames;
    Tnew=[Told;[pnew zeros(size(pnew,1),size(objlist,1))]];
    Tall=array2table(Tnew);
    for i=1:size(pnew,1)
        eval(sprintf('RowName{%d}=''Experiment %d.%d'';',i,size(repl,2)+1,i))
    end
    RowName_new=[RowName_old;RowName'];
    Tall=[RowName_new Tall];
    parlist1=regexprep(parlist1,'[^a-zA-Z0-9]','_');
    objlist1=regexprep(objlist1,'[^a-zA-Z0-9]','_');
    Tall.Properties.VariableNames=['Factors' parlist1 objlist1];
    
     %

%works in windows
    
    %works in windows
    writetable(Tall,f,'WriteVariableNames',true,'WriteRowNames',true);%,'Sheet','Generation 1','Delimiter','tab','FileType','spreadsheet','Range','A1'
end

% hObject    handle to save_new_exp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in adv_set.
function adv_set_Callback(hObject, eventdata, handles)
global parlist_val
A=get(handles.adv_set,'Value');
set(handles.mut_rate,'String','0.01');
set(handles.cross_rate,'String','0.9');
set(handles.nbits,'String','5');
% ind_var=find(parlist_val(:,1)-parlist_val(:,2)~=0);
set(handles.sel_prob,'String',0.5);
if A==1
    set(handles.mut_rate,'Enable','on');
    set(handles.cross_rate,'Enable','on');
    set(handles.nbits,'Enable','on');
    set(handles.sel_prob,'Enable','on');
    set(handles.ga_pars,'Enable','on');
    set(handles.def_ga,'Enable','on');
    set(handles.gen_exp,'Enable','off');
else
    set(handles.mut_rate,'Enable','off');
    set(handles.cross_rate,'Enable','off');
    set(handles.nbits,'Enable','off');
    set(handles.sel_prob,'Enable','off');
    set(handles.ga_pars,'Enable','off');
    set(handles.def_ga,'Enable','off');
    set(handles.gen_exp,'Enable','on');
end

% hObject    handle to adv_set (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns adv_set contents as cell array
%        contents{get(hObject,'Value')} returns selected item from adv_set


% --- Executes during object creation, after setting all properties.
function adv_set_CreateFcn(hObject, eventdata, handles)
% hObject    handle to adv_set (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function mut_rate_Callback(hObject, eventdata, handles)
% hObject    handle to mut_rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mut_rate as text
%        str2double(get(hObject,'String')) returns contents of mut_rate as a double


% --- Executes during object creation, after setting all properties.
function mut_rate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mut_rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function cross_rate_Callback(hObject, eventdata, handles)
% hObject    handle to cross_rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cross_rate as text
%        str2double(get(hObject,'String')) returns contents of cross_rate as a double


% --- Executes during object creation, after setting all properties.
function cross_rate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cross_rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nbits_Callback(hObject, eventdata, handles)
% hObject    handle to nbits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nbits as text
%        str2double(get(hObject,'String')) returns contents of nbits as a double


% --- Executes during object creation, after setting all properties.
function nbits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nbits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sel_prob_Callback(hObject, eventdata, handles)
% hObject    handle to sel_prob (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sel_prob as text
%        str2double(get(hObject,'String')) returns contents of sel_prob as a double


% --- Executes during object creation, after setting all properties.
function sel_prob_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sel_prob (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ga_pars.
function ga_pars_Callback(hObject, eventdata, handles)
global ga_par
A=str2num(get(handles.mut_rate,'String'));
B=str2num(get(handles.cross_rate,'String'));
C=str2num(get(handles.nbits,'String'));
D=str2num(get(handles.sel_prob,'String'));
if and(and(and(and(and(and(and(A>=0,A<=1),B>=0),B<=1),mod(C,1)==0),C<=10),D>=0),D<=1)
    ga_par=[A B C D];
    set(handles.gen_exp,'Enable','on');
else
    warndlg('One or more values of the parameters are not valid. Please check the manual for more details.','Error','modal')
    set(handles.gen_exp,'Enable','off');
end
% hObject    handle to ga_pars (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in def_ga.
function def_ga_Callback(hObject, eventdata, handles)
set(handles.mut_rate,'String','0.01');
set(handles.cross_rate,'String','0.9');
set(handles.nbits,'String','5');
set(handles.nbits,'String','5');
set(handles.gen_exp,'Enable','off');
% hObject    handle to def_ga (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in save_res.
function save_res_Callback(hObject, eventdata, handles)
global usedVals
global par_unit
global parlist_val
global parlist
global idx_sort
global nbins
global ga_par

sel_prob=ga_par(1,4);
A=get(handles.par_list,'Value');
var_par=find(parlist_val(:,1)~=parlist_val(:,2));
n_exp=2*size(var_par,1)-2;
n_sel=ceil(n_exp*sel_prob);
[file,path]=uiputfile('*.xls','Save Experiments');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    if exist(f)
        delete(f)
    end
    label=[];
    results=[];
    freq=[];
    for i=1:size(usedVals{1},2)
        range=[parlist_val(i,1)-(parlist_val(i,2)-parlist_val(i,1))/(nbins-1):(parlist_val(i,2)-parlist_val(i,1))/(nbins-1):parlist_val(i,2)+(parlist_val(i,2)-parlist_val(i,1))/(nbins-1)];
        par=sprintf('%s_%s',parlist{i},par_unit{i}); 
        for j=1:size(usedVals,2)  
            freq{j}=sprintf('Frequency_of_%d_in_%d',i,j);
            pars_hist=usedVals{j}(:,i)+0.0001;
%             pars_hist=round(pars_hist,4);
            [N(j,:),X]=histcounts(pars_hist,range(1,2:end));
        end
        results=[results X(1,1:end-1)' N'];
        label=[label par freq];
    end   
    for i=1:size(usedVals{end},2)
        range=[parlist_val(i,1)-(parlist_val(i,2)-parlist_val(i,1))/(nbins-1):(parlist_val(i,2)-parlist_val(i,1))/(nbins-1):parlist_val(i,2)+(parlist_val(i,2)-parlist_val(i,1))/(nbins-1)];
        par_end=sprintf('%s_%s_last',parlist{i},par_unit{i});
        freq=sprintf('Frequency_of_%d',i);
        pars_hist=usedVals{end}(idx_sort{end}(1:n_sel),i)+0.0001;
%         pars_hist=round(pars_hist,4);
        [N,X]=histcounts(pars_hist,range(1,2:end));
%         if max(size(unique(pars_hist)))==1
%             X=unique(pars_hist).*ones(size(X));
%         end        
        results=[results X(1,1:end-1)' N'];
        label=[label par_end freq];
    end    
    T=array2table(results);
    T.Properties.VariableNames=label;
    writetable(T,f,'WriteVariableNames',true,'WriteRowNames',true);       
%     ind_N=find(sum(N,2)~=0);
%     pars_hist_end=usedVals{end}(idx_sort(1:end/2),A);
%     [N_end,X_end]=hist(pars_hist_end,nbins);
%     
%     parlist1=regexprep(parlist1,'[^a-zA-Z0-9]','_');
    
    
end
set(handles.a_conv,'Enable','on');
set(handles.ok_conv,'Enable','on');
set(handles.gen_new_exp,'Enable','off');
set(handles.save_new_exp,'Enable','off');


% --- Executes on button press in save_scores.
function save_scores_Callback(hObject, eventdata, handles)
global objlist
global objlist_val
global parlist_val
global usedVals
global repl
global ga_par
[file,path]=uiputfile('*.xls','Save Experiments');
if ~isequal(file,0) || ~isequal(path,0)
    f=fullfile(path,file);
    if exist(f)
        delete(f)
    end     
    A=get(handles.par_list,'Value');
    B=get(handles.sel_plot,'Value');
    C=get(handles.obj_list,'Value');
    [Score_o,Score_sort,idx_sort]=calc_score(usedVals,repl,parlist_val,objlist_val,ga_par);
    results=[];
    count=1;
    for i=1:size(usedVals,2)
%         for j=1:size(objlist,1)
%             score(idx_sort{i}(:,j),j)=Score_sort{i}(:,j);
%         end
        for j=1:size(usedVals{i},1)
            eval(sprintf('RowName{%d}=''Experiment %d.%d'';',count,i,j))
            count=count+1;
        end
        results=[results;Score_o{i}'];
    end
    label=[];
    for j=1:size(objlist,1)
        label=[label cellstr(sprintf('Scores_%s',objlist{j}))];
    end
    
    T=array2table(results);
    T=[RowName' T];
    T.Properties.VariableNames=['Experiments' label];
    writetable(T,f,'WriteVariableNames',true,'WriteRowNames',true);
end
set(handles.save_res,'Enable','on');
% hObject    handle to save_scores (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in sel_plot.
function sel_plot_Callback(hObject, eventdata, handles)
% hObject    handle to sel_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sel_plot contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sel_plot


% --- Executes during object creation, after setting all properties.
function sel_plot_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sel_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
