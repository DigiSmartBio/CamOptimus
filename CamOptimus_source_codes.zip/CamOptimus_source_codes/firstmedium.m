% firstmedium.m is part of CamOptimus.
% 
% CamOptimus is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% CamOptimus is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with CamOptimus.  If not, see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file defines the commands for generating the initial random
% population in genetic algorithm.

function pinitial=firstmedium(parlist_val,ga_par)
rng('shuffle')
nbits=ga_par(1,3);
nbins=2^nbits;
var_par=find(parlist_val(:,1)~=parlist_val(:,2));
n_exp=2*size(var_par,1)-2;
if n_exp>1
    for i=1:size(parlist_val,1)
        min1=parlist_val(i,1);
        max1=parlist_val(i,2);
        pbinrange(i,:)=setBinranges(min1,max1,nbins);
    end
    rnd_idx=randi([1,nbins],[n_exp,size(parlist_val,1)]);
    for j=1:size(parlist_val,1)
        pinitial(:,j)=pbinrange(j,rnd_idx(:,j));
    end
%     q = quantizer('fixed','Ceiling','Saturate',[nbits+1 nbits]);
%     bitstrings=[];
%     for j=1:size(pbinrange,1)
%         pinitial(:,j)=pbinrange(j,1)+(pbinrange(j,end)-pbinrange(j,1)).*rand(n_exp,1);
%         [bincounts,ind]=histc(pinitial(:,j),pbinrange(j,:));
%         ybin=num2bin(q,ind./nbins);
%         if isempty(bitstrings),
%             bitstrings=ybin(:,2:end);
%         else
%             bitstrings=[bitstrings ybin(:,2:end)];
%         end
%     end
else
    pinitial=parlist_val(:,1)';
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [binrange]=setBinranges(minR, maxR, step)
    binrange=[minR:(maxR-minR)/(step-1):maxR];
end