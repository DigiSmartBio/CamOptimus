% calc_score.m is part of CamOptimus.
% 
% CamOptimus is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% CamOptimus is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with CamOptimus.  If not, see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file defines the commands for calculating the normalised score of
% each individual.

function [Score,Score_sort,idx_sort]=calc_score(usedVals,repl,parlist_val,objlist_val,ga_par)
nbits=ga_par(1,3);
nbins=2^nbits;
for i=1:size(parlist_val,1)
    min1=parlist_val(i,1);
    max1=parlist_val(i,2);
    pbinrange(i,:)=setBinranges(min1,max1,nbins);
end
for i=1:size(repl,2)
    for j=1:size(usedVals{i},1)
        for jj=1:size(usedVals{i},2)
            [vmin,idxmin]=min(abs(pbinrange(jj,:)-usedVals{i}(j,jj)));
            a=(jj-1)*nbits+1;
            b=(jj)*nbits;
            bitstrUsed(j,a:b)=dec2bin(idxmin-1,nbits);
        end
    end
    for j=1:size(repl{i},2)
        mmin=min(repl{i}(:,j));
        mmax=max(repl{i}(:,j));
        repl_n{i}(:,j)=(repl{i}(:,j)-mmin)./(mmax-mmin);       
    end    
    for j=1:size(objlist_val,1)
        if objlist_val(j,1)==2
            wgt(j)=-1*objlist_val(j,2);
        elseif objlist_val(j,1)==1
            wgt(j)=objlist_val(j,2);
        end
    end
    clear Scores
    for j=1:size(repl{i},1)
        Score{i}(:,j)=wgt.*repl{i}(j,:);
        Score_n{i}(:,j)=wgt.*repl_n{i}(j,:);
    end
    Score_sum=sum(Score_n{i},1);
    [Score_sort{i},idx_sort{i}]=sort(Score_sum,'descend');
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [binrange]=setBinranges(minR, maxR, step)
binrange = [minR:(maxR-minR)/(step-1):maxR];
end